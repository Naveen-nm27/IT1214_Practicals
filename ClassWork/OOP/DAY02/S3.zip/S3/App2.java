import IT.*;
import AMC.*;

class App2 {
	public static void main (String[] args){
		Y01.FirstYear ab=new Y01.FirstYear();
		Y02.SecondYear bc=new Y02.SecondYear();
		
		AMC.Y01 cd=new AMC.Y01;
		
		ab.display();
		bc.display();
	}
}
