package Y01;

public class FirstYear {
	public void display(){
		System.out.println("Hi From IT Y01");
	}
}
