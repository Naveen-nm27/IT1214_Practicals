package IT;

public class IT {
	public void display(){
		System.out.println("Hi From IT");
	}
}
