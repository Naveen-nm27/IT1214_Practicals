package Y02;

public class SeccondYear {
	public void display(){
		System.out.println("Hi From AMC Y02");
	}
}
